from aiogram.types import LabeledPrice
from asyncpg import Connection

from loader import db

class DBCommand:
    pool: Connection = db

    GET_FIRST = 'SELECT first FROM users WHERE chat_id=$1'

    GET_SETTINGS = 'SELECT price_pr, price_st, first_price_pr, first_price_st FROM admin WHERE id=1'

    async def get_first_user(self, id):
        user_first = await self.pool.fetch(self.GET_FIRST, id)
        return user_first[0][0] # TODO: тут ошибка

    async def get_price(self):
        return await self.pool.fetch(self.GET_SETTINGS)



db = DBCommand()


async def gen_buy_price(id):
    first_buy = await db.get_first_user(id) # Вернет True если покупка у человека первая
    prices = []
    price = await db.get_price()
    price = price[0]
    if first_buy:
        prices.append([LabeledPrice('Стандарт', amount=price[3]*100)])
        prices.append([LabeledPrice('Премиум', amount=price[2]*100)])
    else:
        prices.append([LabeledPrice('Стандарт', amount=price[1]*100)])
        prices.append([LabeledPrice('Премиум', amount=price[0]*100)])

    return prices