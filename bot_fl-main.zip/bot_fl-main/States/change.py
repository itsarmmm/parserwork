from aiogram.dispatcher.filters.state import StatesGroup, State

class Change(StatesGroup):
    smm = State()
    smm_save = State()


    site = State()
    site_save = State()


    prog = State()
    prog_save = State()


    design = State()
    design_save = State()


    price = State()
    price_save = State()


    management = State()
    management_save = State()


    marketing = State()
    marketing_save = State()


    premium = State()
    premium_save = State()


    minus = State()
    minus_save = State()

    contextual = State()
    contextual_save = State()

    seo = State()
    seo_save = State()

    copywriting = State()
    copywriting_save = State()

    video = State()
    video_save = State()

    targeted = State()
    targeted_save = State()


