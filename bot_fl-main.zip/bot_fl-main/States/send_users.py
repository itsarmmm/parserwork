from aiogram.dispatcher.filters.state import StatesGroup, State


class Send(StatesGroup):
    get_message = State()
    adoption = State()