from aiogram.dispatcher.filters.state import StatesGroup, State


class Subscriptions(StatesGroup):
    get_subs = State()
    get_phrase = State()