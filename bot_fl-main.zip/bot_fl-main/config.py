from dotenv import load_dotenv
import os
load_dotenv()

API_ID = os.getenv('API_ID') # API id телеграм user
API_HASH = os.getenv('API_HASH') # API хэш телеграм user
ADMIN_ID = os.getenv('ADMIN_ID') # id админа бота
TOKEN_BOT = os.getenv('TOKEN_BOT') # Токен бота
PROVIDER_TOKEN = os.getenv('PROVIDER_TOKEN') # Токен оплаты
# Соединение с БД
PG_PASS = os.getenv('POSTGRES_PASSWORD')
PGHOST = os.getenv('PGHOST')
PG_USER = os.getenv('PG_USER')