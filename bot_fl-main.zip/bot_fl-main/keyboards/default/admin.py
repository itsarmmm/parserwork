from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

admin = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton('Контекстная реклама'),
            KeyboardButton('Таргетированная реклама'),
        ],
        [
            KeyboardButton('Копирайтинг'),
            KeyboardButton('Дизайн'),
            KeyboardButton('Менеджмент'),
        ],
        [
            KeyboardButton('Минус'),
            KeyboardButton('Премиум'),
            KeyboardButton('Цены'),
        ],
        [
            KeyboardButton('SEO'),
            KeyboardButton('Программирование'),
            KeyboardButton('SMM'),
        ],
        [
            KeyboardButton('Создание сайтов'),
            KeyboardButton('Видео'),
        ]
    ],
    resize_keyboard=True
)