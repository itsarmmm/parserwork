from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

panel = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton('Сменить подписки'),
            KeyboardButton('Оплатить подписку')
        ]
    ],
    resize_keyboard=True
)