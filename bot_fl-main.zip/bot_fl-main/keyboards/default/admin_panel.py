from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

admin_panel = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton('Сменить ключевые слова'),
            KeyboardButton('Отправить всем сообщение')
        ]
    ],
    resize_keyboard=True
)