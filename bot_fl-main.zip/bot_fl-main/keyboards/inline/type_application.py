from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.callback_data import CallbackData

tp_app_data = CallbackData('type', 'filter', 'type')

tp_app_in_kb = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text='Стандарт', callback_data=tp_app_data.new(filter='tp_app', type='standart')),
            InlineKeyboardButton(text='Премиум', callback_data=tp_app_data.new(filter='tp_app', type='primium'))
        ]
    ]
)