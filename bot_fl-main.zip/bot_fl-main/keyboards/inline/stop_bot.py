from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from asyncpg import Connection

from loader import db


class DBCommand:
    pool: Connection = db
    GET_USER = 'SELECT stopped FROM users WHERE chat_id=$1'

    async def get_user_stopped(self, id):
        return await self.pool.fetch(self.GET_USER, id)

db = DBCommand()

async def gen_stop_in_kb(id):
    user = await db.get_user_stopped(id)

    if user[0][0] == False:
        markup = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton('Остановить', callback_data='stopped_nof')
                ]
            ]
        )
    else:
        markup = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton('Запустить', callback_data='started_nof')
                ]
            ]
        )
    return markup
