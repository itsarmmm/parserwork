from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.callback_data import CallbackData

ch_price_dt = CallbackData('change', 'filter')

ch_price_in_kb = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton('Стандарт', callback_data=ch_price_dt.new('st')),
            InlineKeyboardButton('Премиум', callback_data=ch_price_dt.new('pr')),
        ],
        [
            InlineKeyboardButton('Стандарт (first)', callback_data=ch_price_dt.new('st_f')),
            InlineKeyboardButton('Премиум (first)', callback_data=ch_price_dt.new('pr_f')),
        ]
    ]
)