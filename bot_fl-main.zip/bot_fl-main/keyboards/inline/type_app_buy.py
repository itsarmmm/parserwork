from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.callback_data import CallbackData


buy_subs_dt = CallbackData('buy', 'subs')

buy_subs_in_kb = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton('Стандарт', callback_data=buy_subs_dt.new('st')),
            InlineKeyboardButton('Премиум', callback_data=buy_subs_dt.new('pr'))
        ]
    ]
)


