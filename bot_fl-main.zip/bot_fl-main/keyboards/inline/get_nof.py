from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

get_nof = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton('Получить заявки', callback_data='get_nof')
        ]
    ]
)