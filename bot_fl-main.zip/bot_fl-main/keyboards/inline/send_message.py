from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.callback_data import CallbackData

send_message_dt = CallbackData('send', 'filter', 'who')

send_message_in_k = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton('Премиум', callback_data=send_message_dt.new(filter='send', who='premium')),
            InlineKeyboardButton('Стандарт', callback_data=send_message_dt.new(filter='send', who='standart')),
        ],
        [
            InlineKeyboardButton('Всем', callback_data=send_message_dt.new(filter='send', who='all'))
        ]
    ]
)