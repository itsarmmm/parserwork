from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.callback_data import CallbackData

sub_dt = CallbackData('sub', 'filter', 'subscriptions')
sub_dt_ch = CallbackData('change', 'filter', 'subscriptions')

sub_in_kb = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton('Контекстная реклама', callback_data=sub_dt.new(filter='subs', subscriptions='contextual')),
            InlineKeyboardButton('Таргетированная реклама', callback_data=sub_dt.new(filter='subs', subscriptions='targeted')),

        ],
        [
            InlineKeyboardButton('SEO', callback_data=sub_dt.new(filter='subs', subscriptions='seo')),
            InlineKeyboardButton('SMM', callback_data=sub_dt.new(filter='subs', subscriptions='smm'))
        ],
        [
            InlineKeyboardButton('Создание сайтов', callback_data=sub_dt.new(filter='subs', subscriptions='site')),
            InlineKeyboardButton('Дизайн', callback_data=sub_dt.new(filter='subs', subscriptions='design'))
        ],
        [
            InlineKeyboardButton('Копирайтинг', callback_data=sub_dt.new(filter='subs', subscriptions='copywriting')),
            InlineKeyboardButton('Программирование', callback_data=sub_dt.new(filter='subs', subscriptions='programming'))
        ],
        [
            InlineKeyboardButton('Менеджмент', callback_data=sub_dt.new(filter='subs', subscriptions='management')),
            InlineKeyboardButton('Видеомейкинг', callback_data=sub_dt.new(filter='subs', subscriptions='video'))
        ],
        [
            InlineKeyboardButton('Продолжить', callback_data=sub_dt.new(filter='starting', subscriptions='None'))
        ]
    ]
)


async def gen_sub_in_kb(data, type=None):
    '''
    Генерирует новую клавиатуру


    :param data: Массив из подключенных позиция *Используется в добавлении позиций handlers/users/start.py*
    :return: InlineKeyboardMarkup
    '''
    contextual = 'Контекстная реклама'
    targeted = 'Таргетированная реклама'
    seo = 'SEO'
    smm = 'SMM'
    site = 'Создание сайтов'
    design = 'Дизайн'
    copywriting = 'Копирайтинг'
    programming = 'Программирование'
    management = 'Менеджмент'
    video = 'Видеомейкинг'


    if 'contextual' in data:
        contextual = '✅ Контекстная реклама'
    if 'targeted' in data:
        targeted = '✅ Таргетированная реклама'
    if 'seo' in data:
        seo = '✅ SEO'
    if 'smm' in data:
        smm = '✅ SMM'
    if 'site' in data:
        site = '✅ Создание сайтов'
    if 'design' in data:
        design = '✅ Дизайн'
    if 'copywriting' in data:
        copywriting = '✅ Копирайтинг'
    if 'programming' in data:
        programming = '✅ Программирование'
    if 'management' in data:
        management = '✅ Менеджмент'
    if 'video' in data:
        video = '✅ Видеомейкинг'


    if type == 'change':
        sub_in_kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(contextual,
                                         callback_data=sub_dt_ch.new(filter='subs', subscriptions='contextual')),
                    InlineKeyboardButton(targeted,
                                         callback_data=sub_dt_ch.new(filter='subs', subscriptions='targeted')),

                ],
                [
                    InlineKeyboardButton(seo, callback_data=sub_dt_ch.new(filter='subs', subscriptions='seo')),
                    InlineKeyboardButton(smm, callback_data=sub_dt_ch.new(filter='subs', subscriptions='smm'))
                ],
                [
                    InlineKeyboardButton(site,
                                         callback_data=sub_dt_ch.new(filter='subs', subscriptions='site')),
                    InlineKeyboardButton(design, callback_data=sub_dt_ch.new(filter='subs', subscriptions='design'))
                ],
                [
                    InlineKeyboardButton(copywriting,
                                         callback_data=sub_dt_ch.new(filter='subs', subscriptions='copywriting')),
                    InlineKeyboardButton(programming,
                                         callback_data=sub_dt_ch.new(filter='subs', subscriptions='programming'))
                ],
                [
                    InlineKeyboardButton(management,
                                         callback_data=sub_dt_ch.new(filter='subs', subscriptions='management')),
                    InlineKeyboardButton(video, callback_data=sub_dt_ch.new(filter='subs', subscriptions='video'))
                ],
                [
                    InlineKeyboardButton('Сохранить',
                                         callback_data=sub_dt_ch.new(filter='exit', subscriptions='None'))
                ]
            ]
        )
        return sub_in_kb

    sub_in_kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(contextual,
                                     callback_data=sub_dt.new(filter='subs', subscriptions='contextual')),
                InlineKeyboardButton(targeted,
                                     callback_data=sub_dt.new(filter='subs', subscriptions='targeted')),

            ],
            [
                InlineKeyboardButton(seo, callback_data=sub_dt.new(filter='subs', subscriptions='seo')),
                InlineKeyboardButton(smm, callback_data=sub_dt.new(filter='subs', subscriptions='smm'))
            ],
            [
                InlineKeyboardButton(site,
                                     callback_data=sub_dt.new(filter='subs', subscriptions='site')),
                InlineKeyboardButton(design, callback_data=sub_dt.new(filter='subs', subscriptions='design'))
            ],
            [
                InlineKeyboardButton(copywriting,
                                     callback_data=sub_dt.new(filter='subs', subscriptions='copywriting')),
                InlineKeyboardButton(programming,
                                     callback_data=sub_dt.new(filter='subs', subscriptions='programming'))
            ],
            [
                InlineKeyboardButton(management,
                                     callback_data=sub_dt.new(filter='subs', subscriptions='management')),
                InlineKeyboardButton(video, callback_data=sub_dt.new(filter='subs', subscriptions='video'))
            ],
            [
                InlineKeyboardButton('Продолжить',
                                     callback_data=sub_dt.new(filter='starting', subscriptions='None'))
            ]
        ]
    )

    return sub_in_kb