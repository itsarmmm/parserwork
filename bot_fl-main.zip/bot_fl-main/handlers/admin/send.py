import asyncio

from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.types import Message, CallbackQuery
from aiogram.utils.exceptions import BotBlocked
from asyncpg import Connection

from States import Send
from config import ADMIN_ID
from keyboards import send_message_in_k, send_message_dt
from loader import dp, db, bot


class DBCommand:
    pool: Connection = db

    GET_USERS = 'SELECT chat_id FROM users WHERE premium=$1'
    GET_ALL_USERS = 'SELECT chat_id FROM users'


    async def get_user(self, premium):
        return await self.pool.fetch(self.GET_USERS, premium)

    async def get_all_users(self):
        return await self.pool.fetch(self.GET_ALL_USERS)



db = DBCommand()

@dp.message_handler(Text(equals='Отправить всем сообщение'), user_id=ADMIN_ID)
async def get_send_user(message: Message):
    await message.answer('Выберете кому отправить:', reply_markup=send_message_in_k)



@dp.callback_query_handler(send_message_dt.filter(filter='send'), user_id=ADMIN_ID)
async def get_message(call: CallbackQuery, callback_data=dict, state=FSMContext):
    data = callback_data.get('who')
    await Send.get_message.set()
    await state.update_data({'who': data})
    await call.answer(cache_time=2)
    await call.message.answer('Введите сообщение:')


@dp.message_handler(state=Send.get_message)
async def adoption(message: Message, state=FSMContext):
    message_user = message.text
    data = await state.get_data()

    await state.update_data({'text': message_user})

    await message.answer(f'Подтвердите отправку сообщения написав "Да" или любой другой текст для отмены\n\n'
                         f'Сообщение:\n'
                         f'{message_user}\n\n'
                         f'Будет отправлено: {data["who"]}')
    await Send.adoption.set()


@dp.message_handler(state=Send.adoption)
async def adoption_message(message: Message, state=FSMContext):
    if message.text == 'Да':
        data = await state.get_data()
        if data['who'] == 'premium':
            users = await db.get_user(True)
        elif data['who'] == 'standart':
            users = await db.get_user(False)
        else:
            users = await db.get_all_users()


        for user in users:
            try:
                await bot.send_message(chat_id=user[0], text=data['text'])
                await asyncio.sleep(0.06)
            except BotBlocked:
                pass


    else:
        await message.answer('Сообщение не будет отправлено')

    await state.finish()




