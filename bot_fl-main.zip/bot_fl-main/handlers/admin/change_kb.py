from aiogram.dispatcher.filters import Text
from aiogram.types import Message

from config import ADMIN_ID
from keyboards import admin
from loader import dp

@dp.message_handler(Text(equals='Сменить ключевые слова'), user_id=ADMIN_ID)
async def change_keyboard(message: Message):
    await message.answer('Выберете категорию для смены слов', reply_markup=admin)
