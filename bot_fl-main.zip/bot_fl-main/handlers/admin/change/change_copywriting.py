from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.types import Message
from asyncpg import Connection

from States import Change
from config import ADMIN_ID
from loader import dp, bot, db

class DBCommand:
    pool: Connection = db
    GET_PROG = 'SELECT copywriting FROM admin WHERE id=1'

    CHANGE_PROG = 'UPDATE admin SET copywriting=$1 WHERE id=1'

    async def get(self):
        prog = await self.pool.fetch(self.GET_PROG)
        return prog[0][0]

    async def change(self, prog):
        await self.pool.execute(self.CHANGE_PROG, prog)


db = DBCommand()

@dp.message_handler(Text(equals='Копирайтинг'), user_id=ADMIN_ID)
async def change(message: Message, state=FSMContext):
    old = await db.get()
    await message.answer(f'Введите новые ключевые слова copywriting через запятую\n\n'
                         f'<b>ВНИМАНИЕ!</b> Новые слова полностью заменят старые\n\n'
                         f'Старые ключевые слова:\n'
                         f'{old}')
    await Change.copywriting.set()
    await state.update_data({'old': old})

@dp.message_handler(state=Change.copywriting)
async def change_words(message: Message, state=FSMContext):
    new = message.text
    await state.update_data({'new': new})
    data = await state.get_data()
    old = data['old']

    await message.answer(f'Ключевые слова \n\n{old}\n\n<b>Будут заменены на:</b>\n\n{new}\n\nЕсли вы подтверждаете действие напишите "Да", Отмена - любой другой текст')

    await Change.copywriting_save.set()


@dp.message_handler(state=Change.copywriting_save)
async def change_words_save(message: Message, state=FSMContext):
    answer = message.text
    data = await state.get_data()
    new = data['new']
    if answer == 'Да':
        try:
            await db.change(new)
            await message.answer('Ключевые слова успешно заменены')
        except Exception as e:
            await message.answer(f'{e}\n\nЕсли вы видете это сообщение то произошла ошибка обратитесь к программисту @mintvizer')
    else:
        await message.answer('Вы отменили сохранение')

    await state.finish()