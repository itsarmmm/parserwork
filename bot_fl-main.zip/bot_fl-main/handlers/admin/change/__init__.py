from .change_price import dp
from .change_minus import dp
from .change_prog import dp
from .change_site import dp
from .change_design import dp
from .change_smm import dp
from .change_context import dp
from .change_copywriting import dp
from .change_management import dp
from .change_premium import dp
from .change_seo import dp
from .change_targeted import dp
from .change_video import dp






