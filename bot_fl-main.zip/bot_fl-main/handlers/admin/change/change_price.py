from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.types import Message, CallbackQuery
from asyncpg import Connection

from States import Change
from config import ADMIN_ID
from keyboards import ch_price_in_kb
from keyboards.inline.change_price import ch_price_dt
from loader import dp, db, bot

class DBCommand:
    pool: Connection = db
    CHANGE_PRICE_ST = 'UPDATE admin SET price_st=$1 WHERE id=1'
    CHANGE_PRICE_PR = 'UPDATE admin SET price_pr=$1 WHERE id=1'
    CHANGE_PRICE_ST_F = 'UPDATE admin SET first_price_st=$1 WHERE id=1'
    CHANGE_PRICE_PR_F = 'UPDATE admin SET first_price_pr=$1 WHERE id=1'

    async def change_price(self, tb, price):
        if tb == 'price_st':
            await self.pool.execute(self.CHANGE_PRICE_ST, price)
        elif tb == 'price_pr':
            await self.pool.execute(self.CHANGE_PRICE_PR, price)
        elif tb == 'first_price_st':
            await self.pool.execute(self.CHANGE_PRICE_ST_F, price)
        else:
            await self.pool.execute(self.CHANGE_PRICE_PR_F, price)


db = DBCommand()

@dp.message_handler(Text(equals='Цены'), user_id=ADMIN_ID)
async def change_price(message: Message):
    text = 'Выберете какую цену Вам надо сменить\n\nСлово first означает цену на первую покупку'
    await message.answer(text, reply_markup=ch_price_in_kb)


@dp.callback_query_handler(ch_price_dt.filter())
async def get_position(call: CallbackQuery, callback_data=dict, state=FSMContext):
    await Change.price.set()
    data = callback_data.get('filter')
    if data == 'st':
        await state.update_data({'tb': 'price_st'})
    elif data == 'pr':
        await state.update_data({'tb': 'price_pr'})
    elif data == 'st_f':
        await state.update_data({'tb': 'first_price_st'})
    else:
        await state.update_data({'tb': 'first_price_pr'})

    await call.answer(cache_time=.5)
    await call.message.answer('Введите новую цену в рублях')


@dp.message_handler(state=Change.price)
async def add_price(message: Message, state=FSMContext):
    data = await state.get_data()
    price = int(message.text)

    await db.change_price(data['tb'], price)
    await message.answer('Цена успешно сменена')
    await state.finish()
