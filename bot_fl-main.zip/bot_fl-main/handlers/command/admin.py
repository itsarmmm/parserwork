from aiogram.dispatcher.filters import Command
from aiogram.types import Message
from asyncpg import Connection

from config import ADMIN_ID
from keyboards import admin_panel
from loader import dp, bot, db

class DBCommand:
    pool: Connection = db

    GET_COUNT_USERS = "SELECT COUNT(*) FROM users;"
    GET_COUNT_USERS_SUBS = "SELECT COUNT(*) FROM users WHERE days > 0;"

    async def get_count_users(self):
        return await self.pool.fetchval(self.GET_COUNT_USERS)

    async def get_count_users_subs(self):
        return await self.pool.fetchval(self.GET_COUNT_USERS_SUBS)


db = DBCommand()


@dp.message_handler(Command('admin'), user_id=ADMIN_ID)
async def admin_panel_(message: Message):
    count_users = await db.get_count_users()
    count_users_subs = await db.get_count_users_subs()

    text = f'<b>Админ панель</b>\n' \
           f'В Вашем боте сейчас {count_users} пользователей\n' \
           f'Из {count_users} пользователей пользуются подпиской {count_users_subs}'

    await message.answer(text, reply_markup=admin_panel)