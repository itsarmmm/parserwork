from aiogram.dispatcher.filters import Command
from aiogram.types import Message, User
from asyncpg import Connection

from keyboards import panel, gen_stop_in_kb
from loader import dp, db

class DBCommand:
    pool: Connection = db

    GET_USERS = 'SELECT * FROM users WHERE chat_id=$1;'

    async def get_users(self):
        id = User.get_current().id
        return await self.pool.fetch(self.GET_USERS, id)


db = DBCommand()

@dp.message_handler(Command('panel'))
async def user_panel(message: Message):
    user = await db.get_users()

    if user == []:
        await message.answer('Вы еще не зарегистрировались введите "Старт"')
        return

    text = f'Это ваш личный кабинет!\nУ вас осталось {user[0][4]}(дней подписки)'
    markup = await gen_stop_in_kb(message.from_user.id)
    await message.answer('Вы можете остановить бота и он больше не будет присылать вакансии, но время подписки будет продолжать идти!', reply_markup=markup)
    await message.answer(text, reply_markup=panel)

