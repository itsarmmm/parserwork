from aiogram.dispatcher.filters import Command
from aiogram.types import Message

from config import ADMIN_ID
from loader import dp, bot


@dp.message_handler(Command('start'))
async def print_start_info(message: Message):
    name_bot = await bot.get_me()
    text = f'Здравствуйте, я "{name_bot.first_name}". Каждый час я анализирую сотни телеграмм каналов и подбираю самые интересные заявки для IT-специалистов и фрилансеров.\n\n' \
           'Работать со мной крайне просто. Укажите на какие виды услуг Вы хотите получать заказы, параметры заявки и каждый день получайте десятки предложений по Вашим критериям.\n\n' \
           'Что бы начать напишите слово "Старт"'
    if message.chat.id == int(ADMIN_ID):
        text += '\n\nВы админ - чтобы зайти в админ панель отправьте /admin'

    await message.answer(text)