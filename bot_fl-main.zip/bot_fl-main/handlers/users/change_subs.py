from aiogram.dispatcher.filters import Text
from aiogram.types import Message, User, CallbackQuery
from aiogram.utils.exceptions import MessageNotModified
from asyncpg import Connection

from keyboards.inline.subscriptions_in_kb import gen_sub_in_kb, sub_dt_ch
from loader import dp, db, bot

class DBCommand:
    pool: Connection = db

    GET_USER = 'SELECT subscription FROM users WHERE chat_id=$1'

    UPDATE_SUB = 'UPDATE users SET subscription=$1 WHERE chat_id=$2'

    async def get_user_subs(self):
        return await self.pool.fetch(self.GET_USER, User.get_current().id)

    async def update_subs(self, subs):
        args = subs, User.get_current().id
        await self.pool.execute(self.UPDATE_SUB, *args)



db = DBCommand()
@dp.message_handler(Text(equals='Сменить подписки'))
# TODO: тут какая то ошибка?
async def change_subs(message: Message):
    user_subs = await db.get_user_subs()
    user_subs = user_subs[0][0].split(',')
    markup = await gen_sub_in_kb(user_subs, 'change')
    await message.answer('Поменяйте подписки, помните больше 2х выбирать нельзя!', reply_markup=markup)




@dp.callback_query_handler(sub_dt_ch.filter(filter='subs'))
async def getter_subs(call: CallbackQuery, callback_data = dict):
    chosen = callback_data.get('subscriptions')

    user_subs = await db.get_user_subs()
    user_subs = user_subs[0][0].split(',')

    if '' in user_subs:
        user_subs.remove('')

    if chosen in user_subs:
        user_subs.remove(chosen)

        await db.update_subs(','.join(user_subs))
        await call.answer(cache_time=0.5)
    else:
        user_subs.append(chosen)
        if len(user_subs) > 2:
            await call.answer(text='Нельзя выбрать больше 2х подписок')
            user_subs.pop()
        else:
            await call.answer(cache_time=0.5)
    try:
        markup = await gen_sub_in_kb(user_subs, 'change')

        await db.update_subs(','.join(user_subs))
        await call.message.edit_reply_markup(markup)
    except MessageNotModified:

        await db.update_subs(','.join(user_subs))


@dp.callback_query_handler(sub_dt_ch.filter(filter='exit'))
async def getter_subs(call: CallbackQuery, callback_data = dict):
    await call.answer(cache_time=.5)
    await call.message.edit_reply_markup(None)
    await call.message.edit_text('Ваши новые подписки успешно сохранены!')
