from .start import dp
from .buy_subs import dp
from .change_subs import dp
from .buy_subs_panel import dp
from .stop_nof import dp
from .get_nof import dp


from ._default_ import dp