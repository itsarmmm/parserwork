from aiogram.types import CallbackQuery
from asyncpg import Connection

from keyboards import gen_stop_in_kb
from loader import dp, bot, db

class DBCommand:
    pool: Connection = db

    UPDATE_STOPPED = 'UPDATE users SET stopped=$1 WHERE chat_id=$2'

    async def update_stopped(self, stopped, id):
        args = stopped, id
        await self.pool.execute(self.UPDATE_STOPPED, *args)


db = DBCommand()

@dp.callback_query_handler(text='stopped_nof')
async def stop_nof(call: CallbackQuery):
    await db.update_stopped(True, call.from_user.id)
    await call.answer(cache_time=0.5)

    markup = await gen_stop_in_kb(call.from_user.id)
    await call.message.edit_reply_markup(reply_markup=markup)



@dp.callback_query_handler(text='started_nof')
async def stop_nof(call: CallbackQuery):
    await db.update_stopped(False, call.from_user.id)
    await call.answer(cache_time=0.5)
    markup = await gen_stop_in_kb(call.from_user.id)
    await call.message.edit_reply_markup(reply_markup=markup)
