from aiogram.types import Message

from loader import dp

@dp.message_handler()
async def send_undestand_user(message: Message):
    await message.answer('Я вас не понимаю :(')