from aiogram.types import CallbackQuery, PreCheckoutQuery, Message, User, ContentType, SuccessfulPayment
from asyncpg import Connection

from config import PROVIDER_TOKEN, ADMIN_ID
from keyboards import get_nof
from keyboards.inline.type_app_buy import buy_subs_dt
from loader import dp, bot, db
from prices import gen_buy_price


class DBCommand:
    pool: Connection = db

    GET_DAYS_USER = 'SELECT days, first FROM users WHERE chat_id=$1'

    SET_DAYS = 'UPDATE users SET days=$1 WHERE chat_id=$2'
    SET_PR = 'UPDATE users SET premium=$1 WHERE chat_id=$2'
    SET_F = 'UPDATE users SET first=FALSE WHERE chat_id=$1'
    GET_FIRST = 'SELECT first FROM users WHERE chat_id=$1'

    async def is_first(self):
        user_id = User.get_current().id
        result = await self.pool.fetch(self.GET_FIRST, user_id)
        return result[0][0]

    async def get_days(self, id):
        return await self.pool.fetch(self.GET_DAYS_USER, id)

    async def update_days(self, days, pr, id):
        args_d = days, id
        args_p = pr, id
        await self.pool.execute(self.SET_DAYS, *args_d)
        await self.pool.execute(self.SET_PR, *args_p)
        await self.pool.execute(self.SET_F, id)


db = DBCommand()


@dp.callback_query_handler(buy_subs_dt.filter())
async def get_score_price(call: CallbackQuery, callback_data=dict):
    pr = callback_data.get('subs')
    await call.answer(cache_time=.5)
    prices = await gen_buy_price(call.message.chat.id)
    first = await db.is_first()

    if first:
        text = 'Вам предоставлен тестовый период на 3 дня\n' \
               'В случае возникновения вопросов обращайтесь к администратору @paren_bez_imeni \n\n' \
               'Для изменения условий оплаты, смены тарифа и других задач используйте ваш личный кабинет по ссылке /panel.\n\n' \
               '________________________________________\n' \
               '😎ParserWork - работа для фрилансеров! \n\n' \
               '<b>Для получения заявок нажмите кнопку "Получить заявки" ниже.</b>'

        await db.update_days(3, True, call.from_user.id)
        await call.message.answer(text, reply_markup=get_nof)

        return

    if pr == 'pr':
        pr = True
        await bot.send_invoice(
            chat_id=call.from_user.id,
            title='Премиум пакет',
            description='Премиум заявки (лучшие проекты со средним чеком от 30 000 рублей)',
            payload='premium',
            provider_token=PROVIDER_TOKEN,
            start_parameter='pr',
            currency='RUB',
            prices=prices[1]
        )
    else:
        pr = False
        await bot.send_invoice(
            chat_id=call.from_user.id,
            title='Стандарт пакет',
            description='Стандартные заявки (от разовых задач до постоянной работы, бюджет до 30 000 рублей)',
            payload='standart',
            provider_token=PROVIDER_TOKEN,
            start_parameter='st',
            currency='RUB',
            prices=prices[0]
        )


@dp.pre_checkout_query_handler()
async def checkout_pay(query: PreCheckoutQuery):
    # days_user = await db.get_days(query.from_user.id)
    #
    # pr = query.invoice_payload

    #
    # if days_user[0][1]:
    #     days_user = days_user[0][0] + 7
    # else:
    #     days_user = days_user[0][0] + 7

    # await db.update_days(days_user, pr, query.from_user.id)
    await bot.answer_pre_checkout_query(query.id, True, 'Извините, но что-то пошло не так!')
    await bot.send_message(chat_id=query.from_user.id,
                           text='Если Ваша оплата прошла без ошибок. Вам придет сообщение')
    # text_admin = f'Кто-то оплатил подписку {query.invoice_payload} за {query.total_amount / 100} рублей!'
    # await bot.send_message(chat_id=ADMIN_ID, text=text_admin)


@dp.message_handler(content_types=ContentType.SUCCESSFUL_PAYMENT)
async def process_successful_payment(message: Message):
    days_user = await db.get_days(message.from_user.id)
    days_user = days_user[0][0] + 7

    pmnt: SuccessfulPayment = message.successful_payment

    print(pmnt)
    payload = pmnt.invoice_payload
    if payload == 'premium':
        type = True
    else:
        type = False

    await db.update_days(days_user, type, message.from_user.id)

    await bot.send_message(chat_id=message.from_user.id,
                           text='Ваша оплата поступила. В течении 5 минут вы получите 10 заявок , а далее заявки будут вам поступать каждые 20 минут.'
                                '\n\nДля изменения условий оплаты, смены тарифа и других задач используйте ваш личный кабинет по ссылке /panel.\n\n'
                                'В случае возникновения вопросов обращайтесь к администратору @paren_bez_imeni \n\n'
                                '________________________________________\n'
                                '😎ParserWork - работа для фрилансеров! \n\n'
                                '<b>Для получения заявок нажмите кнопку "Получить заявки" ниже.</b>',
                           reply_markup=get_nof)
    text_admin = f'Кто-то оплатил подписку {pmnt.invoice_payload} за {pmnt.total_amount / 100} рублей!'
    await bot.send_message(chat_id=ADMIN_ID, text=text_admin)
