from aiogram.dispatcher.filters import Text
from aiogram.types import CallbackQuery, Message, User
from asyncpg import Connection

from config import PROVIDER_TOKEN
from keyboards.inline.type_app_buy import buy_subs_dt, buy_subs_in_kb
from loader import bot, dp, db
from prices import gen_buy_price


class DBCommand:
    pool: Connection = db
    GET_FIRST = 'SELECT first FROM users WHERE chat_id=$1'

    async def is_first(self):
        user_id = User.get_current().id
        result = await self.pool.fetch(self.GET_FIRST, user_id)
        return result[0][0]


db = DBCommand()


@dp.message_handler(Text(equals='Оплатить подписку'))
async def get_type_applications(message: Message):
    text = 'Отлично! Я уже начал подбирать самые подходящие заявки для Вас. Однако осталось всего лишь оформить подписку. Цена - 199р (990р премиум) в месяц. Согласитесь, вряд ли где-то ещё можно получать сотни заявок в месяц по цене нескольких чашек кофе в день.\n\n' \
           'Однако для Вас супер предложение!\n\n' \
           'Первый месяц подписки всего 99 (199р премиум) рублей. После подписки Вы подключитесь к боту и начнете ежедневно получать десятки заявок.'

    await message.answer(text, reply_markup=buy_subs_in_kb)


@dp.callback_query_handler(buy_subs_dt.filter())
async def get_score_price(call: CallbackQuery, callback_data=dict):
    pr = callback_data.get('subs')
    await call.answer(cache_time=.5)
    prices = await gen_buy_price(call.message.chat.id)

    if pr == 'pr':
        pr = True
        await bot.send_invoice(
            chat_id=call.from_user.id,
            title='Премиум пакет',
            description='Премиум заявки (лучшие проекты со средним чеком от 30 000 рублей)',
            payload='premium',
            provider_token=PROVIDER_TOKEN,
            start_parameter='pr',
            currency='RUB',
            need_name=True,
            prices=prices[1]
        )
    else:
        pr = False
        await bot.send_invoice(
            chat_id=call.from_user.id,
            title='Стандарт пакет',
            description='Стандартные заявки (от разовых задач до постоянной работы, бюджет до 30 000 рублей)',
            payload='standart',
            provider_token=PROVIDER_TOKEN,
            start_parameter='st',
            currency='RUB',
            need_name=True,
            prices=prices[0]
        )
