'''
Здесь добавляются подписки на рубрики
'''
import logging

from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.types import Message, CallbackQuery, User
from aiogram.utils.exceptions import MessageNotModified
from asyncpg import Connection

from States import Subscriptions
from keyboards import sub_in_kb, tp_app_in_kb, buy_subs_in_kb  # Забираем готовую клавиатуру
from keyboards.inline.subscriptions_in_kb import sub_dt, gen_sub_in_kb
from loader import dp, db


class DBCommand:
    pool: Connection = db

    IS_REGISTER = 'SELECT * FROM users WHERE chat_id=$1'

    REGISTER_NEW_USER = "INSERT INTO users (chat_id, subscription) VALUES ($1, $2)"

    async def is_register(self):
        id = User.get_current().id
        user = await self.pool.fetch(self.IS_REGISTER, id)
        if user == []:
            return False
        else:
            return True

    async def register_user(self, subscription):
        try:
            id = User.get_current().id
            args = id, subscription
            await self.pool.execute(self.REGISTER_NEW_USER, *args)
        except Exception as e:
            print(e)


db = DBCommand()

@dp.message_handler(Text(equals='Старт'))
async def get_pod(message: Message, state=FSMContext):
    reg = await db.is_register()
    if reg:
        await message.answer('Вы уже зарегестрированы введите команду /panel что бы попасть в личный кабинет')
    else:

        text = 'Выберите категории услуг, на которые Вы хотите получать заявки. Вы можете указать до 2х категорий'
        await message.answer(text, reply_markup=sub_in_kb)
        await Subscriptions.get_subs.set()
        await state.update_data({'chosen': []})


@dp.callback_query_handler(sub_dt.filter(filter='subs'), state=Subscriptions.get_subs)
async def getter_subs(call: CallbackQuery, callback_data = dict, state=FSMContext):
    chosen = callback_data.get('subscriptions')
    data = await state.get_data()
    new_arr_chosen = data['chosen']
    if chosen in new_arr_chosen:
        new_arr_chosen.remove(chosen)
        await call.answer(cache_time=0.5)

    else:
        new_arr_chosen.append(chosen)
        if len(new_arr_chosen) > 2:
            await call.answer(text='Нельзя выбрать больше 2х подписок')
            new_arr_chosen.pop()
        else:
            await call.answer(cache_time=0.5)
    try:
        markup = await gen_sub_in_kb(new_arr_chosen)
        await state.update_data({'chosen': new_arr_chosen})
        await call.message.edit_reply_markup(markup)
    except MessageNotModified:
        await state.update_data({'chosen': new_arr_chosen})




@dp.callback_query_handler(sub_dt.filter(filter='starting'),state=Subscriptions.get_subs)
async def get_phrase(call: CallbackQuery, callback_data = dict, state=FSMContext):
    await call.answer(cache_time=.5)
    data = await state.get_data()
    subs = ','.join(data['chosen'])

    text ='Отлично! Я уже начал подбирать самые подходящие заявки для Вас. Однако осталось всего лишь оформить подписку. Цена - 199р (990р премиум) в месяц. Согласитесь, вряд ли где-то ещё можно получать сотни заявок в месяц по цене нескольких чашек кофе в день.\n\n' \
           'Однако для Вас супер предложение!\n\n' \
           'Первый месяц подписки всего 99 (199р премиум) рублей. После подписки Вы подключитесь к боту и начнете ежедневно получать десятки заявок.\n\n'\
            'Какие заявки вы хотите получать?\n\n' \
           '- Стандартные заявки (от разовых задач до постоянной работы, бюджет до 30 000 рублей)\n\n' \
           '- Премиум заявки (лучшие проекты со средним чеком от 30 000 рублей)'
    await call.message.answer(text, reply_markup=buy_subs_in_kb)
    await db.register_user(subs)
    await state.finish()






