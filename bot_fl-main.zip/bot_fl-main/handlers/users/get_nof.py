import asyncio

from aiogram.types import User, CallbackQuery
from asyncpg import Connection

from loader import dp, db

class DBCommand:
    pool: Connection = db

    GET_USER_SUBS = 'SELECT subscription FROM users WHERE chat_id=$1'

    GET_POSTS = 'SELECT post, from_user FROM posts WHERE type=$1 OR type=$2 LIMIT 10'

    async def get_user(self):
        id = User.get_current().id
        return await self.pool.fetch(self.GET_USER_SUBS, id)

    async def get_posts(self, subs):
        if len(subs) > 0:
            if subs[0] == '':
                return False
            if len(subs) < 2:
                args = subs[0], None
            else:
                args = subs[0], subs[1]

        return await self.pool.fetch(self.GET_POSTS, *args)


db = DBCommand()
@dp.callback_query_handler(text='get_nof')
async def get_nof(call: CallbackQuery):
    await call.answer(cache_time=.5)
    await call.message.edit_reply_markup()
    subs = await db.get_user()
    subs = subs[0][0].split(',')
    posts = await db.get_posts(subs)
    if posts == False:
        await call.message.answer('У вас нет категорий')
        return

    for post in posts:
        text = f'{post[0]}'
        if post[1] == None:
            pass
        else:
            text += f'\n\nОткликнуться: {post[1]}'
        await call.message.answer(text)
        await asyncio.sleep(0.03)


