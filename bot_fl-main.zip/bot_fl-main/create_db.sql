create table if not exists posts
(
	id serial
		constraint table_name_pk
			primary key,
	type varchar(50),
	post text,
	premium boolean,
	date varchar(50),
	sended boolean default FALSE,
	from_user varchar(250)
);
create unique index if not exists posts_post_uindex
    on posts (post);

create table if not exists users
(
    id           serial not null
        constraint users_pk
            primary key,
    chat_id      integer,
    premium      boolean default false,
    subscription varchar(100),
    days         integer default 0,
    first        boolean default true,
    stopped     boolean default false
);

create unique index if not exists users_chat_id_uindex
    on users (chat_id);

create table if not exists admin
(
	id integer
		constraint admin_pk
			primary key,
	price_st integer default 199,
	price_pr integer default 990,
	first_price_st integer default 1,
	first_price_pr integer default 1,
	smm text,
	design text,
	programming text,
	site text,
	minus text,
	management text,
	premium text,
	contextual text,
    seo text,
    copywriting text,
    video text,
    targeted text
);
