import asyncio
import logging

import aioschedule as schedule
from aiogram import executor
from asyncpg import Connection

from config import ADMIN_ID
from functions import send_exit_subs, debuction_days, delete_old_posts, sending, send_stopped_bot
from loader import bot, db
from parser.app import client
from sql import create_db


class DBCommand:
    pool: Connection = db

    IN_ADMIN = 'INSERT INTO admin (id, smm, design, programming, site, minus, management, premium, contextual, seo, copywriting, video, targeted) VALUES ' \
               '($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)'

    async def insert_setting(self, smm, design, programming, site, minus, management, premium, contextual, seo,
                             copywriting, video, targeted):
        args = 1, smm, design, programming, site, minus, management, premium, contextual, seo, copywriting, video, targeted
        await self.pool.execute(self.IN_ADMIN, *args)


db = DBCommand()


async def open_shedule():
    schedule.every().day.at('22:00').do(
        debuction_days)  # Уменьшает количество дней подписки на 1 и отправляет отчет админу
    schedule.every().day.at('22:00').do(
        send_exit_subs)  # Отправляет пользователям (у которых осталось меньше 5 дней подписки) сообщение о скором окончании подписки
    schedule.every().day.at('04:00').do(
        send_stopped_bot)  # Отправляет пользователям сообщение о том что бот перестает работать ночью
    schedule.every(3).days.do(delete_old_posts)  # Удаляет старые отправленные посты

    schedule.every(20).minutes.do(sending, 'contextual')  # Отправляет пользователям вакансии по contextual
    schedule.every(20).minutes.do(sending, 'targeted')  # Отправляет пользователям вакансии по targeted
    schedule.every(20).minutes.do(sending, 'seo')  # Отправляет пользователям вакансии по seo
    schedule.every(20).minutes.do(sending, 'smm')  # Отправляет пользователям вакансии по smm
    schedule.every(20).minutes.do(sending, 'site')  # Отправляет пользователям вакансии по site
    schedule.every(20).minutes.do(sending, 'design')  # Отправляет пользователям вакансии по design
    schedule.every(20).minutes.do(sending, 'copywriting')  # Отправляет пользователям вакансии по copywriting
    schedule.every(20).minutes.do(sending, 'programming')  # Отправляет пользователям вакансии по programming
    schedule.every(20).minutes.do(sending, 'management')  # Отправляет пользователям вакансии по management
    schedule.every(20).minutes.do(sending, 'video')  # Отправляет пользователям вакансии по video

    while True:
        await schedule.run_pending()
        await asyncio.sleep(10)


async def on_shutdown(dp):
    await bot.close()


async def on_client_bot():
    'Запуск telethon из parser и отслеживание сообщений в боте'
    await client.start()
    await client.run_until_disconnected()


async def on_startup(dp):
    # Подождем пока запустится база данных...
    await create_db()
    await asyncio.sleep(20)
    await bot.send_message(ADMIN_ID, "Я запущен!")

    asyncio.create_task(on_client_bot())
    asyncio.create_task(open_shedule())

    try:
        smm = 'SMM,smmщик,СММ,сторис,сторисмейкер,ведение,подписчики,аккаунт,телеграм,продвижение telegram'
        design = 'дизайн,дизайнер,логотип,визитки,листовки,брендбук,фирменный стиль,сверстать,оформить,нарисовать,упаковать,упаковка,презентация,фотошоп,photoshop,coraldraw,figma,фигма,веб-дизайн,веб-дизайнер,фотообработка,taplink,таплинк,креатив,макет'
        programming = 'Программист,программирование,back end,front end,бэкенд,фронтенд,middle,senior,тестировщик,java,javascript,mysql,html,css,c#,c++,php,python,devops,node.js,разработчик,Linux,developer,fullstack,фулстек,engineer,ruby,unity,вёрстка,верстка,crm'
        site = 'Создать сайт,разработать сайт,сделать сайт,лендинг,landing,квиз,создать интернет магазин,wordpress,wordpres,вордпрес,вордпресс,тильда,tilda,джумла,joomla,друпал,drupal,Bitrix,посадочная страница,продающая страница,доработка сайта,доделать сайт,правки сайт'
        minus = 'помогу,для вас,меня зовут,ставка,выигрыш,секс,порно,сиськи,разврат,интим,отзыв,подписывайся,подпишись,вступи,вступай,регистрируйся,запишись,зарегистрируйся,регистрируйтесь,запишитесь,добро пожаловать,таверна,подборка,бесплатно,халявку,помогаю,предлагаю,message,подборка,#дайджест,сделаю,продам,продаю,заглушил,скидка,подпишитесь,Message,перепродажа'
        management = 'менеджер,звонки,колл центр,оператор,телемаркетолог,рекрутер,ассистент,помощник директора,прием звонков,обработка заявок,обслуживание клиентов,секретарь,project,project-менеджер,проект-менеджер,аккаунт-менеджер,account-менеджер,документовед,управляющий'
        premium = 'horseatremote,GetExpert,tonionjobs,rabota_udalennaya,normrabota,workoo,progjob,relance50K,perezvonyu,inwork_udalenka,theyseeku,digital_rabota,remote_ru,smmlancer,jobkawork,hh_vacancy_udalenka,distantsiya,naudalenkebro,pandawork_birzha,datasciencejobs,qa_jobs,jobscode_infull,ucan_job,dddwork,hr_itwork,self_ma,devops_jobs_feed,javascript_jobs_feed,remowork_ru,seohr,workfreelancer,karerist,divanjobs,freelanceworkhome,jobinmarketingua,Remoteit,Work4writers,zona_f,mediajobs_ru,jobmar,vakansii5,workathomerus,devjobs,WORKER_HOME,vezdeworker,digitaljob_ch,udalenka_exe,zrabota,ru_pythonjobs,remote_work20,marketing_jobs,digital_hr,vacanciesrus,workplaces,dnative_job,theyseeku_it,yojob,workwhereveryouwant,edujobs,prwork,goodpeople_pro,homester'
        contextual = 'контекст,контекстная,adwords,яндекс директ,директолог,контекстолог,адвордс,ads,маркетолог,рся,кмс,keykollector,кейколлектор,вордстат,wordstat,веб-аналитика,веб аналитика,analytics,яндекс метрика,елама,elama,роистат,roistat,коммандер'
        seo = 'SEO,продвижение яндекс,продвижение google,продвижение гугл,продвижение в топ,продвижение сайта,оптимизация сайта,поисковая оптимизация,ссылочная масса,раскрутка сайта,раскрутка интернет магазина,раскрутка яндекс,раскрутка google,раскрутка гугл,метатеги,sitemap,ранжирование,seopult,promopult,gogetlinks,sape'
        copywriting = 'Наполнение,копирайт,копирайтер,копирайтинг,рерайт,рерайтинг,рерайтер,контент,контент-план,написание статей,написать текст,редактировать текст,SEO-тексты,лонгрид,главред,email,рассылки,LSI,LSI-копирайтинг,сторителлинг,longrid,автопостинг'
        video = 'Видеографика,видеомейкер,видеоролик,видеопрезентация,анимация,проморолик,промо ролик,редактировать видео,обработка видео,видеомонтаж, видео монтаж,видеомонтажер,анимированное видео,видеообзор,3D,слайдшоу,дудл-видео,дудл видео,заставка видео,обработка аудио,обработка звука,звукомонтажер,звукорежиссер,транскрибация,аудиоролик,аудиозапись'
        targeted = 'mytarget,таргетинг,таргет,таргетированная,таргетолог,ЦА,целевая аудитория,реклама ВК,реклама VK,реклама вконтакте,реклама Facebook,реклама Фейсбук,реклама FB,реклама вконтакте,реклама Instagram,реклама Инстаграм,реклама YouTube,реклама ютуб,арбитраж'
        await db.insert_setting(smm, design, programming, site, minus, management, premium, contextual, seo,
                                copywriting, video, targeted)

    except Exception as e:
        logging.info(e)


if __name__ == '__main__':
    from handlers import dp

    executor.start_polling(dp, on_shutdown=on_shutdown, on_startup=on_startup)
