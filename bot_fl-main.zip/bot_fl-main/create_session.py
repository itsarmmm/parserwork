import asyncio

from telethon.sync import TelegramClient

from config import API_ID, API_HASH

client = TelegramClient('session/my_session', API_ID, API_HASH)

if __name__ == '__main__':
    client.start()