import logging
from datetime import datetime
from difflib import SequenceMatcher

import emoji
import regex
from asyncpg import Connection, UniqueViolationError
from telethon.events import NewMessage
from telethon.sync import TelegramClient
from telethon.tl.types import Channel, User

from config import API_ID, API_HASH
from loader import db


async def split_count(text):
    emoji_counter = 0
    data = regex.findall(r'\X', text)
    for word in data:
        if any(char in emoji.UNICODE_EMOJI for char in word):
            emoji_counter += 1

    return emoji_counter


logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s', level=logging.INFO)
client = TelegramClient('session/my_session', API_ID, API_HASH)


# vacancy


class DBCommand:
    pool: Connection = db

    ADD_NEW_FL = 'INSERT INTO posts (type, post, premium, date, from_user) VALUES ($1, $2, $3, $4, $5)'
    GET_POSTS = 'SELECT * FROM posts;'
    GET_WORDS = "SELECT contextual, targeted, seo, smm, site, design, copywriting, programming, management, video, premium, minus  FROM admin WHERE id=1"

    async def get_posts(self):
        return await self.pool.fetch(self.GET_POSTS)

    async def add_new_fl(self, type, post, premium, date, from_user):
        args = type, post, premium, date, from_user
        await self.pool.execute(self.ADD_NEW_FL, *args)

    async def get_words(self):
        return await self.pool.fetch(self.GET_WORDS)


db = DBCommand()


@client.on(NewMessage)
async def get_info(event: NewMessage.Event):
    # Для проверки группа это или канал
    chat: Channel = await event.get_chat()  # chat объект Channel - chat.username - имя чата
    sended_msg = event.message.message  # отправленное сообщение

    # Проверочные слова для поиска совпадений
    words = await db.get_words()
    contextual = words[0][0].split(',')
    targeted = words[0][1].split(',')
    seo = words[0][2].split(',')
    smm = words[0][3].split(',')
    site = words[0][4].split(',')
    design = words[0][5].split(',')
    copywriting = words[0][6].split(',')
    programming = words[0][7].split(',')
    management = words[0][8].split(',')
    video = words[0][9].split(',')
    premium = words[0][10].split(',')
    minus = words[0][11].split(',')

    # Дата
    today = datetime.today()
    today = str(datetime(today.year, today.month, today.day))
    type_post = False

    posts = await db.get_posts()  # Все посты
    logging.info('Процесс... Жду дальнейшего оповещения')

    for text in minus:
        if text in sended_msg.lower():
            logging.info(text)
            logging.info('Не пропущено минус')
            return

    try:
        from_user = await client.get_entity(event.message.from_id)

        if type(from_user) == User:
            if from_user.username == 'None' or from_user.username == None:
                return
            from_user = f'@{from_user.username}'
        else:
            from_user = None

    except Exception as e:
        from_user = None

    # Определение типа чата
    if chat.username in premium:
        print('Чат премиум')
        type_post = True

    if 'https://t.me/' in sended_msg:
        logging.info('Не пропущено ссылка')
        return

    for post in posts:
        if SequenceMatcher(None, sended_msg, post[2]).ratio() > 0.8:
            logging.info('Найдено совпадение текста больше чем на 80%')
            return

    logging.info('Дошло до регистрации')
    adoption = await get_identification(sended_msg, contextual, 'contextual', type_post, today, from_user)

    if adoption:
        return

    adoption = await get_identification(sended_msg, targeted, 'targeted', type_post, today, from_user)

    if adoption:
        return

    adoption = await get_identification(sended_msg, seo, 'seo', type_post, today, from_user)

    if adoption:
        return

    adoption = await get_identification(sended_msg, smm, 'smm', type_post, today, from_user)

    if adoption:
        return

    adoption = await get_identification(sended_msg, site, 'site', type_post, today, from_user)

    if adoption:
        return

    adoption = await get_identification(sended_msg, design, 'design', type_post, today, from_user)

    if adoption:
        return

    adoption = await get_identification(sended_msg, copywriting, 'copywriting', type_post, today, from_user)

    if adoption:
        return

    adoption = await get_identification(sended_msg, programming, 'programming', type_post, today, from_user)

    if adoption:
        return

    adoption = await get_identification(sended_msg, management, 'management', type_post, today, from_user)

    if adoption:
        return

    adoption = await get_identification(sended_msg, video, 'video', type_post, today, from_user)

    if adoption:
        return

    logging.info('Совпадений не найдено')


async def get_identification(vacancy, words, data_db, type, today, from_user):
    vacancy_ad = False
    for word in words:
        if word in vacancy.lower():
            vacancy_ad = True
    if vacancy_ad:
        vacancy += '\n\n______________________________________\nParserWork😎 - работа для фрилансеров\n\nПодпишитесь на наш Telegram канал и получайте десятки предложений каждый день бесплатно - @parserwork'

        try:

            await db.add_new_fl(data_db, vacancy, type, today, from_user)
            logging.info(f'Слово на {data_db} добавлено')
            return True
        except UniqueViolationError:
            return False
