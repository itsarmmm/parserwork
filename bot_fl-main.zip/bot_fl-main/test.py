# Дата
from datetime import datetime

today = datetime.today()
print(type(today.hour))
type_post = False