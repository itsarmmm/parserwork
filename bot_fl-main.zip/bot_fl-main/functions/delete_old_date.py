import asyncio
import logging
from datetime import datetime, timedelta

from asyncpg import Connection

from loader import db


class DBCommand:
    pool: Connection = db
    GET_POSTS = 'SELECT id, date FROM posts WHERE sended=TRUE;'
    DELETE_POST = 'DELETE FROM posts WHERE id=$1'

    async def get_posts(self):
        return await self.pool.fetch(self.GET_POSTS)

    async def delete_post(self, id):
        await self.pool.execute(self.DELETE_POST, id)

db = DBCommand()


async def delete_old_posts():
    posts = await db.get_posts()
    today = datetime.today()
    today = datetime(today.year, today.month, today.day)
    for post in posts:
        if datetime.strptime(post[1], '%Y-%m-%d %H:%M:%S') < today.timedelta(days=-3):
            await db.delete_post(post[0])
