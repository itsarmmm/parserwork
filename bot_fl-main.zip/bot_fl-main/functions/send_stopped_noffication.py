import asyncio
import logging

from aiogram.utils.exceptions import BotBlocked
from asyncpg import Connection

from loader import db, bot

class DBCommand():
    pool: Connection = db
    GET_USERS = 'SELECT chat_id FROM users WHERE days > 0;'

    async def get_users(self):
        return await self.pool.fetch(self.GET_USERS)

db = DBCommand()


async def send_stopped_bot():
        users = await db.get_users()

        for user in users:
            try:
                await bot.send_message(chat_id=user[0], text='Время работы чат-бота на сегодня завершено. Заявки начнут поступать Вам в 08:00 по Москве')
                await asyncio.sleep(0.04)
            except BotBlocked:
                logging.info(f'{user[0]} заблокировал бота')