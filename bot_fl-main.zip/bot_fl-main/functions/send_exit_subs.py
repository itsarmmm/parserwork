import logging

from asyncpg import Connection

from loader import db, bot

class DBCommand():
    pool: Connection = db
    GET_USERS = 'SELECT * FROM users WHERE days <= 2;'

    async def get_users(self):
        return await self.pool.fetch(self.GET_USERS)

db = DBCommand()

async def send_exit_subs():
    users = await db.get_users()

    null_days_str = ''

    for user in users:

        days_string = 'дней'
        if user[4] < 5 and user[4] > 1:
            days_string = 'дня'
        elif user[4] == 1:
            days_string = 'день'
        elif user[4] == 0:
            null_days_str = '<b>Ваша подписка больше не действует</b>'

        text = f'У вас осталось {user[4]} {days_string} подписки, оплатите подписку еще на 30 дней!\n\n{null_days_str}'
        try:
            await bot.send_message(chat_id=user[1], text=text)
        except Exception:
            logging.info(f'Бот заблокирован пользователем {user[1]}\n {user}')

