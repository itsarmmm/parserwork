import asyncio
import logging
from datetime import datetime

from aiogram.utils.exceptions import BotBlocked
from asyncpg import Connection

from loader import db, bot
from aiogram import md


class DBCommand:
    pool: Connection = db

    SENDED_TRUE = 'UPDATE posts SET sended=TRUE WHERE id=$1'

    GET_USERS = 'SELECT * FROM users WHERE days > 0 AND stopped=FALSE;'

    GET_POSTS = "SELECT * FROM posts WHERE type=$1 AND sended=FALSE AND date=$2 LIMIT 1;"

    async def get_users(self, type):
        users = await self.pool.fetch(self.GET_USERS)

        new_user_arr = []

        for user in users:
            if type in user[3]:
                new_user_arr.append([user[1], user[2]])

        return new_user_arr

    async def get_posts(self, type):
        today = datetime.today()
        today = str(datetime(today.year, today.month, today.day))
        args = type, today
        return await self.pool.fetch(self.GET_POSTS, *args)

    async def sended_true(self, id):
        await self.pool.execute(self.SENDED_TRUE, id)


db = DBCommand()


async def send(posts, users):
    for post in posts:
        post_text = post[2]

        # if post[6] == None:
        #     pass
        # else:
        #     post_text += f'\n\nОткликнуться: {post[6]}'

        post_text = md.quote_html(post_text)
        for user in users:
            try:
                if user[1]:
                    await bot.send_message(chat_id=user[0], text=post_text)
                    await asyncio.sleep(0.3)
                else:
                    if post[3]:
                        continue
                    else:
                        await bot.send_message(chat_id=user[0], text=post_text)
                        await asyncio.sleep(0.3)
            except BotBlocked:
                logging.info(f'пользователь блокировал бота {user[0]}')

        await db.sended_true(post[0])


async def sending(type):
    today = datetime.today()

    if today.hour > 4 and today.hour < 12:
        return

    users = await db.get_users(type)
    posts = await db.get_posts(type)
    await send(posts, users)