from asyncpg import Connection

from config import ADMIN_ID
from loader import db, bot

class DBCommand():
    pool: Connection = db
    GET_USERS = 'SELECT * FROM users WHERE days > 0;'
    SET_NEW_DAY = 'UPDATE users SET days=$1 WHERE id=$2'

    async def get_users(self):
        return await self.pool.fetch(self.GET_USERS)


    async def set_new_day(self):
        users = await self.get_users()

        for user in users:
            new_days = user[4] - 1
            await self.pool.execute(self.SET_NEW_DAY, new_days, user[0])


db = DBCommand()

async def debuction_days():
    await db.set_new_day()
    await bot.send_message(ADMIN_ID, text='Подписки всех пользователей уменьшены на 1')
